import React, {Component} from 'react'

class MainPageTitle extends Component { 

  
    render(){ 
      return <div>Welcome to anonymous grading!</div>
    }
  
  }

  export default MainPageTitle