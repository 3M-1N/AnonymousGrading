# AnonymousGrading

Group: 1093

Members: Mateescu Razvan, Mazzini Sebastian, Miron Cristina, Naum Laurentiu

# Planning
  - The users will be able to sign up/log in. all the accounts are going to be stored in a database and the passwords will be encrypted.
  
   <img src= https://github.com/3M-1N/AnonymousGrading/blob/main/Documents/ProjectUI/login.jpeg>
  
  - There will be the possibility of creating a professor account that will only be able to see all the projects and the grades, but not who graded them. The professor will be able to assign students to project teams.
  
  - The students who are members of a team will provide a link to the github repository containing the project in order for this to be graded by the jury. Optionally the students 
will be able to provide a demonstration video for their project that will be automatically played on the project page.

 <img src= https://github.com/3M-1N/AnonymousGrading/blob/main/Documents/ProjectUI/projects.jpeg>

  - The jury consists of 6 randomly chosen members. Only the members of the jury can add grades, and the grades can only be modified by their owners but only 
for a limited period of time. 

<img src= https://github.com/3M-1N/AnonymousGrading/blob/main/Documents/ProjectUI/grades.jpeg>

  - Once a student is selected as member of a jury, he/she will be able to see the project that needs to be graded in the "Contributions" page. Also in this page there 
will be a button that allows a grade to be modified for a short period of time.
  
  <img src= https://github.com/3M-1N/AnonymousGrading/blob/main/Documents/ProjectUI/contributions.jpeg>



## TO-DO:

Cristina - UI Design

Laur - Verifica prezentari + Intereseaza-te de Storage

Razvan - Idei noi pentru planning

Seba - Idei noi pentru planning + Intereseaza-te de Storage (Proiecte, Eventual integrare cu GIT, Integrare cu video player pe site)

